WendzelNNTPd FAQ
================

### Q: Where can I find the documentation and the FAQ?

A: The official documentation as well as the FAQ can be found on the
   Project website https://cdpxe.github.io/WendzelNNTPd/

### Q: Can I convert an old v.1.4.x database file to the 2.x database file format?

A: Yes. There is a hack-quality solution for that. Please check the documentation.
