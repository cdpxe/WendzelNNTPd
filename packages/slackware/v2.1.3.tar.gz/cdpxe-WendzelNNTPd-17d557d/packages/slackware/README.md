This directory contains Slackware build scripts.

- The tarball on sf.net usually includes the Slackbuild script of the previous version. The latest Slackbuild version of the Slackbuild script is always on [github.com's wendzelnntpd repository](https://github.com/cdpxe/WendzelNNTPd/tree/master/packages/slackware), while the latest stable version of the Slackbuild script is always on the [official Slackbuild website](https://slackbuilds.org/repository/14.2/network/wendzelnntpd/).

- You can alternatively download the Slackware packages from Sourceforge.net (they are already built, so you only need to run `installpkg (filename)`): [https://sourceforge.net/projects/wendzelnntpd/files/v2.1.2/slackware64-current-package/](https://sourceforge.net/projects/wendzelnntpd/files/v2.1.2/slackware64-current-package/).
